// import { TestBed } from '@angular/core/testing';
//
// import { HeaderComponent } from './header.component';
//
// describe('About Component', () => {
//   beforeEach(() => {
//     TestBed.configureTestingModule({declarations: [HeaderComponent]});
//   });
//
//   it('should ...', () => {
//     const fixture = TestBed.createComponent(HeaderComponent);
//     fixture.detectChanges();
//     expect(fixture.nativeElement.children[0].textContent).toContain('About Works!');
//   });
//
// });
